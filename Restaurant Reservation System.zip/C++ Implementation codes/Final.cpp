#include<iostream>
#include<fstream>
#include<cstdlib>
#include<stdlib.h>
#include<algorithm>
#include<string.h>
#include<sstream>
#include<vector>
#include<conio.h>
#include<iomanip>

using namespace std;

    char decision;
    string deleteline,line,search;
    int Order_no,offset, Quantity,i,j,choose;
     string name,price;
     double charge=5.00,rates=0.06,tax;



     string convert(string str){ //(word to change)=convert(word to change)
    for(int i=0; i<str.length();i++){
        str[i]=toupper(str[i]);
    }
    return str;
}

//used to initialize based on space
void mainmenu();
void feedback();
void displaymenu();
void add_reservation();
void delete_reservation();
void sortname();
//end here

void maindisplay()
{
    system("COLOR 3F");
    cout << ("\n\t\t\t =================================================================\n");
    cout << ("\t\t\t ************* ONLINE RESTAURANT RESERVATION SYSTEM **************\n");
    cout << ("\t\t\t =================================================================\n\n");
    cout << "\t\t\t1) LOGIN AS ADMIN\n" << endl;
    cout << "\t\t\t==================================================================\n" << endl;
    cout << "\t\t\t2) PROCEED AS CUSTOMER\n" << endl;
    cout << "\t\t\t==================================================================\n" << endl;
    cout << "\t\t\t3) EXIT" << endl;
    cout << "\t\t\t==================================================================\n" << endl;
    cout << "Your choice: ";
}


void adminmenu()
{
    int adminchoice;

    system("cls");
    cout<<("\n\t\t\t =================================================================\n");
    cout<<("\t\t\t ************* ONLINE RESTAURANT RESERVATION SYSTEM **************\n");
    cout<<("\t\t\t =================================================================\n");
    cout<<"Welcome back, Admin."<<endl;
    cout<<"What would you like to do today ?"<<endl;
    cout<<"1)Sort all reservation details"<<endl;
    cout<<"2)Delete reservations"<<endl;
    cout<<"3)Go back to main menu"<<endl;
    cout<<"Your choice: ";
    cin>>adminchoice;

    while(adminchoice < 1 || adminchoice > 3){
        cout << "Invalid choice, try again.\n";
        cin >> adminchoice;
    }

    if(adminchoice == 1){
        sortname();
    }

    if(adminchoice == 2){
        delete_reservation();
    }

    if(adminchoice == 3){
        mainmenu();
    }

}

void customermenu() //void option
{
    int customerchoice;
    string namecust, numguest, date, time, phone;

    system("cls");
    cout<<("\n\t\t\t =================================================================\n");
    cout<<("\t\t\t ************* ONLINE RESTAURANT RESERVATION SYSTEM **************\n");
    cout<<("\t\t\t =================================================================\n");
    cout<<endl;
    cout<<"Welcome to our restaurant reservation system."<<endl;
    cout<<"What would you like to do today ?"<<endl;
    cout<<endl;
    cout<<"1)Make reservation"<<endl;
    cout<<"2)Display menu"<<endl;
    cout<<"3)Give Feedback"<<endl;
    cout<<"4)Go back to main menu"<<endl;
    cout<<"Your choice: ";
    cin>>customerchoice;

    while(customerchoice < 1 || customerchoice > 4){
        cout << "Invalid choice, try again.\n";
        cin >> customerchoice;
    }

    if(customerchoice == 1){
        add_reservation();
    }

    else if(customerchoice == 2){
        displaymenu();
    }

    else if(customerchoice == 3){
        feedback();
    }

    else if(customerchoice == 4){
        mainmenu();
    }


}

void FoodOrder(){


    std::cout << fixed << setprecision(2);
    string name, price;
    vector<string>fname;
    vector<double>fprice;

    int i = 0;

    ifstream food("Foods.txt");
    if (food.is_open())
    {
        while (!food.eof())
        {
            getline(food,name,'|');
            fname.push_back(name);
            getline(food,price,'\n');
            fprice.push_back(stod(price));

            i+=1;
        }
        food.close();
        cout<<"\t\t\tNumber of entries: "<<i<<endl;
    }
    else cout << "Unable to open file";

    cout<<"\t\t\tFood names"<< "\t\t"<<"Price"<<endl;

    for(int j =0; j<i;j++){
        cout<<endl<<"\t\t\t["<<j+1<<"]"<<fname[j]<< "\tRM"<<fprice[j];

    }
                        int n,q;
                        cout<<endl<<endl<<"\t\t\tEnter your order number: ";
                        cin>>n;


                        cout<<"\t\t\tEnter quantity: ";
                        cin>>q;

                        cout<<endl<<"\t\t\tPreorder: ";
                        cout<<endl<<"\t\t\t--------------------------------";
                        cout<<endl<<"\t\t\tFood: "<<fname[n-1]<<endl<<"\t\t\tQuantity: "<<q<<endl<<"\t\t\tPrice: RM "<< fprice[n-1]*q;
                        cout<<endl<<"\t\t\t--------------------------------"<<endl;

                        ofstream myfile("cart.txt",std::ofstream::app);
                        myfile<< std::fixed << std::setprecision(2);
                        myfile<<"F"<<n<<"|"<<fname[n-1]<<"|"<<q<<"|"<<fprice[n-1]*q<<endl;
                        myfile.close();


}


void DrinkOrder(){


   std::cout << fixed << setprecision(2);
    string name, price;
    vector<string>dname;
    vector<double>dprice;

    int i = 0;

    ifstream drink("Drinks.txt");
    if (drink.is_open())
    {
        while (!drink.eof())
        {
            getline(drink,name,'|');
            dname.push_back(name);
            getline(drink,price,'\n');
            dprice.push_back(stod(price));

            i+=1;
        }
        drink.close();
        cout<<"\t\t\tNumber of entries: "<<i<<endl;
    }
    else cout << "Unable to open file";

    cout<<"\t\t\tDrink names"<< "\t\t"<<"Price"<<endl;
    //i=i-1;
    for(int j =0; j<i;j++){
        cout<<endl<<"\t\t\t["<<j+1<<"]"<<dname[j]<< "\tRM"<<dprice[j];

    }
                        int n,q;
                        cout<<endl<<endl<<"\t\t\tEnter your order number: ";
                        cin>>n;


                        cout<<"\t\t\tEnter quantity: ";
                        cin>>q;

                        cout<<endl<<"\t\t\tPreorder: ";
                        cout<<endl<<"\t\t\t--------------------------------";
                        cout<<endl<<"\t\t\tDrink: "<<dname[n-1]<<endl<<"\t\t\tQuantity: "<<q<<endl<<"\t\t\tPrice: RM "<< dprice[n-1]*q;
                        cout<<endl<<"\t\t\t--------------------------------"<<endl;

                        ofstream myfile("cart.txt",std::ofstream::app);
                        myfile<< std::fixed << std::setprecision(2);
                        myfile<<"D"<<n<<"|"<<dname[n-1]<<"|"<<q<<"|"<<dprice[n-1]*q<<endl;
                        myfile.close();



}
void DessertOrder(){


     std::cout << fixed << setprecision(2);
    string name, price;
    vector<string>dename;
    vector<double>deprice;

    int i = 0;

    ifstream dessert("Desserts.txt");
    if (dessert.is_open())
    {
        while (!dessert.eof())
        {
            getline(dessert,name,'|');
            dename.push_back(name);
            getline(dessert,price,'\n');
            deprice.push_back(stod(price));

            i+=1;
        }
        dessert.close();
        cout<<"\t\t\tNumber of entries: "<<i<<endl;
    }
    else cout << "Unable to open file";

    cout<<"\t\t\tDrink names"<< "\t\t"<<"Price"<<endl;
    //i=i-1;
    for(int j =0; j<i;j++){
        cout<<endl<<"\t\t\t["<<j+1<<"]"<<dename[j]<< "\tRM"<<deprice[j];

    }
                        int n,q;
                        cout<<endl<<endl<<"\t\t\tEnter your order number: ";
                        cin>>n;


                        cout<<"\t\t\tEnter quantity: ";
                        cin>>q;

                        cout<<endl<<"\t\t\tPreorder: ";
                        cout<<endl<<"\t\t\t--------------------------------"<<endl;
                        cout<<endl<<"\t\t\tDrink: "<<dename[n-1]<<endl<<"\t\t\tQuantity: "<<q<<endl<<"\t\t\tPrice: RM "<< deprice[n-1]*q;
                        cout<<endl<<"\t\t\t--------------------------------"<<endl;

                        ofstream myfile("cart.txt",std::ofstream::app);
                        myfile<< std::fixed << std::setprecision(2);
                        myfile<<"S"<<n<<"|"<<dename[n-1]<<"|"<<q<<"|"<<deprice[n-1]*q<<endl;
                        myfile.close();

}

void Cart(){

       std::cout << fixed << setprecision(2);
    string name, price,quantity,code;
    vector<string>ccode;
    vector<string>cname;
    vector<int>cquantity;
    vector<double>cprice;

    int  i = 0;
    double total=0;

    ifstream cart("cart.txt");
    if (cart.is_open())
    {
        while (!cart.eof())
        {
            getline(cart,code,'|');
            ccode.push_back(code);
            getline(cart,name,'|');
            cname.push_back(name);
            getline(cart,quantity,'|');
            cquantity.push_back(stoi(quantity));
            getline(cart,price,'\n');
            cprice.push_back(stod(price));

            i+=1;
        }
        cart.close();
        cout<<"\t\t\tNumber of entries: "<<i-1<<endl;
        i--;
    }
    else cout << "Unable to open file";
    cout<<"\t\t\tYour order(s):"<<endl;
    cout<<"\t\t\tCode"<<"\tName"<<"\t\tQuantity"<<"\tPrice";
    for(int j =0; j<i;j++){
        cout<<endl<<"\t\t\t["<<ccode[j]<<"]"<<"\t"<<cname[j]<< "\t"<<cquantity[j]<< "\tRM"<<cprice[j];
        total+=cprice[j];
    }
    tax=total*rates;
    cout<<endl<<"\t\t\t---------------------------------------------------";
    cout<<endl<<"\t\t\t\t\t\t Total\t       :RM"<<total;
    cout<<endl<<"\t\t\t\t\t\t Service Charge:RM"<<charge;
    cout<<endl<<"\t\t\t\t\t\t Service Tax 6%:RM"<<tax;
    cout<<endl<<"\t\t\t\t\t\t --------------------------";
    cout<<endl<<"\t\t\t\t\t\t Total Sales\t:RM"<<total+charge+tax;
}
void DisplayFood(){
    ifstream food("Foods.txt");
    int i=1;
    string name,price;
         cout<<"\t\t\tFood names"<< "\t\t"<<"Price"<<endl;
         while (!food.eof())
        {
        getline(food,name,'|');

        getline(food,price,'\n');


        cout<<endl<<"\t\t\t["<<i<<"]"<<name<<"\tRM"<<price;
        i++;
        }
}
void DisplayDesserts(){

     ifstream dessert("Desserts.txt");
    int i=1;

         cout<<"\t\t\tDessert names"<< "\t\t"<<"Price"<<endl;
         while (!dessert.eof())
        {
        getline(dessert,name,'|');

        getline(dessert,price,'\n');


        cout<<endl<<"\t\t\t["<<i<<"]"<<name<<"\tRM"<<price;
        i++;
        }
}
void DisplayDrink(){

    ifstream drink("Drinks.txt");
    int i=1;

         cout<<"\t\t\tDrink names"<< "\t\t"<<"Price"<<endl;
         while (!drink.eof())
        {
        getline(drink,name,'|');

        getline(drink,price,'\n');


        cout<<endl<<"\t\t\t["<<i<<"]"<<name<<"\tRM"<<price;
        i++;
        }
}



void CreateCart(){
    ofstream myfile("cart.txt",std::ofstream::app);
    myfile<<"Your carts:";
}
void InitialCart(){
    std::ofstream myfile;
    myfile.open("cart.txt", std::ofstream::out | std::ofstream::trunc);
    myfile.close();
}
void DeleteCart(){
    system("cls");
    std::cout << fixed << setprecision(2);
    string name, price,quantity,code,del;
    vector<string>ccode;
    vector<string>cname;
    vector<int>cquantity;
    vector<double>cprice;

    int  i = 0;
    double dtotal=0, total=0;

    ifstream cart("cart.txt");
    if (cart.is_open())
    {
        while (!cart.eof())
        {
            getline(cart,code,'|');
            ccode.push_back(code);
            getline(cart,name,'|');
            cname.push_back(name);
            getline(cart,quantity,'|');
            cquantity.push_back(stoi(quantity));
            getline(cart,price,'\n');
            cprice.push_back(stod(price));

            i+=1;
        }
        cart.close();
       cout<<"\t\t\tNumber of entries: "<<i-1<<endl;
        i--;
    }
    else cout << "Unable to open file";
    cout<<"\t\t\tYour order(s):"<<endl;
    cout<<"\t\t\tCode"<<"\tName"<<"\t\tQuantity"<<"\tPrice";
    for(int j =0; j<i;j++){
        cout<<endl<<"\t\t\t["<<ccode[j]<<"]"<<"\t"<<cname[j]<< "\t"<<cquantity[j]<< "\tRM"<<cprice[j];
        total+=cprice[j];
    }
    cout<<endl<<"\t\t\t---------------------------------------------------";
    cout<<endl<<"\t\t\t Your total:\tRM"<<total;

    vector<string>dcode;
    vector<string>dname;
    vector<int>dquantity;
    vector<double>dprice;

    cout<<endl<<endl<<"\t\t\tEnter number to delete: ";
    cin>>del;
    del=convert(del);
    ofstream temp("temp.txt",std::ofstream::app);
    //copy content that are different than input
    for(int i=0; i<ccode.size(); i++)
    {
        if(ccode.at(i)!=del){
        dcode.push_back(ccode.at(i));
        dname.push_back(cname.at(i));
        dquantity.push_back(cquantity.at(i));
        dprice.push_back(cprice.at(i));
        }

    }
    i--;
    system("cls");
    cout<<"\t\t\tYour order(s):"<<endl;
    cout<<"\t\t\tCode"<<"\tName"<<"\t\t\tQuantity"<<"Price";
    for(int j =0; j<i;j++){
        cout<<endl<<"\t\t\t["<<dcode[j]<<"]"<<"\t"<<dname[j]<< "\t"<<dquantity[j]<< "\tRM"<<dprice[j];
        temp<<dcode[j]<<"|"<<dname[j]<< "|"<<dquantity[j]<< "|"<<dprice[j]<<endl;
        dtotal+=dprice[j];
    }

       cout<<endl<<"\t\t\t---------------------------------------------------";
        cout<<endl<<"\t\t\t\t\t\t Your total:\tRM"<<dtotal;
    temp.close();
    cart.close();
    remove("cart.txt");
   rename("temp.txt", "cart.txt");
}



void UpdateCart(){
   system("cls");
    std::cout << fixed << setprecision(2);
    string name, price,quantity,code,update;
    vector<string>ccode;
    vector<string>cname;
    vector<int>cquantity;
    vector<double>cprice;

    int  newq,i = 0;
    double dtotal=0, total=0;
     vector<string>dcode;
    vector<string>dname;
    vector<int>dquantity;
    vector<double>dprice;

    ifstream cart("cart.txt");
    ofstream temp("temp.txt",std::ofstream::trunc);

    if (cart.is_open())
    {
        while (!cart.eof())
        {
            getline(cart,code,'|');
            ccode.push_back(code);
            getline(cart,name,'|');
            cname.push_back(name);
            getline(cart,quantity,'|');
            cquantity.push_back(stoi(quantity));
            getline(cart,price,'\n');
            cprice.push_back(stod(price));

            i+=1;
        }
        cart.close();
         cout<<"\t\t\tNumber of entries: "<<i-1<<endl;
        i--;
    }
    else cout << "Unable to open file";
    cout<<"\t\t\tYour order(s):"<<endl;
    cout<<"\t\t\tCode"<<"\tName"<<"\t\tQuantity"<<"\tPrice";
    for(int j =0; j<i;j++){
        cout<<endl<<"\t\t\t["<<ccode[j]<<"]"<<"\t"<<cname[j]<< "\t"<<cquantity[j]<< "\tRM"<<cprice[j];
        total+=cprice[j];
    }
    cout<<endl<<"\t\t\t---------------------------------------------------";
    cout<<endl<<"\t\t\t\t\t\t Your total:\tRM"<<total;
    cout<<endl<<"\t\t\tEnter code to be updated:";
    cin>>update;
    update=convert(update);
    //copy content that are different than input
    for(int i=0; i<ccode.size(); i++)
    {
        if(ccode.at(i)!=update){
        dcode.push_back(ccode.at(i));
        dname.push_back(cname.at(i));
        dquantity.push_back(cquantity.at(i));
        dprice.push_back(cprice.at(i));
        }

    }
    i--;

    cout<<"\t\t\tYour order(s):"<<endl;
    cout<<"\t\t\tCode"<<"\tName"<<"\t\t\tQuantity"<<"Price";
    for(int j =0; j<i;j++){
        //cout<<endl<<j+1<<")"<<dcode[j]<<"\t"<<dname[j]<< "\t"<<dquantity[j]<< "\tRM"<<dprice[j];
        temp<<dcode[j]<<"|"<<dname[j]<< "|"<<dquantity[j]<< "|"<<dprice[j]<<endl;
        dtotal+=dprice[j];
    }
    i++;
    //select the same array content
    for(int k=0;k<i;k++)
    {
        if(ccode[k]==update)
        {
            cout<<endl<<"\t\t\t["<<ccode[k]<<"]\t"<<cname[k]<< "\t"<<cquantity[k]<< "\tRM"<<cprice[k]<<endl;
            cprice[k]=cprice[k]/cquantity[k];
            cout<<"\t\t\tEnter new quantity:\t";
            cin>>cquantity[k];
            cprice[k]=cprice[k]*cquantity[k];
            cout<<endl<<"\t\t\t["<<ccode[k]<<"]\t"<<cname[k]<< "\t"<<cquantity[k]<< "\tRM"<<cprice[k];
            temp<<ccode[k]<<"|"<<cname[k]<< "|"<<cquantity[k]<< "|"<<cprice[k]<<endl;
        }
    }
   temp.close();
   cart.close();
   remove("cart.txt");
   rename("temp.txt", "cart.txt");
}

void Food(){


            DisplayFood();
            std::cout <<endl<<endl<< "\t\t\tPress Y to pre-order: "<<endl<<"\t\t\tPress N to go back to the Main Menu: ";
            std::cin >> decision;
            decision = toupper(decision);
            while (decision !='Y' && decision !='N')
            {
            std::cout <<endl<< "\t\t\tInvalid, try again: ";
            std::cout <<endl<< "\t\t\tPress Y to pre-order: "<<endl<<"\t\t\tPress N to go back to the Main Menu: ";
            std::cin >> decision;
            decision = toupper(decision);
            system("cls");
            DisplayFood();
            }
            if(decision=='Y'){

                    do{
                        system("cls");
                        FoodOrder();
                        cout<<"\t\t\tPress Y to add more: ";
                        cout<<endl<< "\t\t\tPress any key to go back to Main Menu: ";
                        std::cin >> decision;
                        decision = toupper(decision);
                        }
                    while(decision == 'Y');

            }
            if (decision=='N'){
                system("cls");
                return ;
            }
            system("cls");

            }

void Drink(){

            DisplayDrink();
            std::cout <<endl<<endl<< "\t\t\tPress Y to pre-order: "<<endl<<"\t\t\tPress N to go back to the Main Menu: ";
            std::cin >> decision;
            decision = toupper(decision);
            while (decision !='Y' && decision !='N')
            {
             std::cout <<endl<< "\t\t\tInvalid, try again: ";
            std::cout <<endl<< "\t\t\tPress Y to pre-order: "<<endl<<"\t\t\tPress N to go back to the Main Menu: ";
            std::cin >> decision;
            decision = toupper(decision);
            system("cls");
            DisplayDrink();
            }
            if(decision=='Y'){
                    do{
                            system("cls");
                        DrinkOrder();
                        cout<<"\t\t\tPress Y to add more: ";
                        cout<<endl<< "\t\t\tPress any key to go back to Main Menu: ";
                        std::cin >> decision;
                        decision = toupper(decision);
                        }
                    while(decision == 'Y');
            }
            if (decision=='N'){
                system("cls");
                return ;
            }
            system("CLS");
            }

void Dessert(){

        DisplayDesserts();
             std::cout <<endl<<endl<< "\t\t\tPress Y to pre-order: "<<endl<<"\t\t\tPress N to go back to the Main Menu: ";
            std::cin >> decision;
            decision = toupper(decision);
            while (decision !='Y' && decision !='N')
            {
            std::cout <<endl<< "\t\t\tInvalid, try again: ";
            std::cout <<endl<< "\t\t\tPress Y to pre-order: "<<endl<<"\t\t\tPress N to go back to the Main Menu: ";
            std::cin >> decision;
            decision = toupper(decision);
            system("cls");
            DisplayDesserts();
            }
            if(decision=='Y'){
                    do{
                        system("cls");
                        DessertOrder();
                        cout<<"\t\t\tPress Y to add more: ";
                        cout<<endl<< "\t\t\tPress any key to go back to Main Menu: ";
                        std::cin >> decision;
                        decision = toupper(decision);
                        }
                    while(decision == 'Y');
            }
            if (decision=='N'){
                system("cls");
                return ;
            }
            system("CLS");
}
void combine(){
    ifstream Food("Foods.txt",ios::app);
    ifstream Drink("Drinks.txt",ios::app);
    ifstream Dessert("Desserts.txt",ios::app);

    ofstream temp("tmp.txt");

    while (getline(Food,line))
    {

            temp << line << endl;

    }
    while (getline(Drink,line))
    {

            temp << line << endl;

    }
    while (getline(Dessert,line))
    {

            temp << line << endl;

    }
    temp.close();
    Food.close();
    Drink.close();
    Dessert.close();
}
void Search(){

    string search,line,pri;
    char decision;
     do {
    combine();
    ifstream temp("tmp.txt",ios::app);
    cout<<"\t\t\tPlease write the name of your searching: ";
    cin>>search;

    if(temp.is_open()) {
    unsigned int curLine = 0;
    cout<<"\t\t\tBelow are the result(s)"<<endl;
    cout<<"\t\t\tName:"<< "\t\t\t"<<"Price:"<<endl<<endl;

    //read file
    while(!temp.eof()) {
    getline(temp, line,'|');
    getline(temp, pri,'\n');
    curLine++;

    //display result
    if (line.find(search, 0) != string::npos) {

        cout <<"\t\t\t"<<line<< "\tRM"<<pri << endl;
    }
    }
    }
    temp.close();
    cout<<endl<< "\t\t\tPress Y to search again:  ";
    cout<<endl<<"\t\t\tPress any key to go back to Main Menu:  ";
    std::cin >> decision;
    decision = toupper(decision);
    cout<<endl;
    system("cls");
    }
    while(decision == 'Y');







}



void add_reservation(){

        string name, numguest, date, time, phone;



                    ofstream reservation("reservation.txt", ios::app);

                    system ("cls");
                    cout<<"\n\t*************** ADD RESERVATION ***************\n\n";
                    cout << "\n\t=================================================" << endl;
                    cout << "\t\t Please fill in the information" << endl;
                    cout << "\t===================================================" << endl;



                    cout << "\n\t\t What is your name? ";
                    cin >> name;
                    name=convert(name);
                    reservation <<endl<< name << '|';


                    cout << "\n\t\t How many person for this reservation? ";
                    cin >> numguest;
                    reservation << numguest << '|';


                    cout << "\n\t\t Enter reservation date (in format DD/MM/YYYY): ";
                    cout << "\n\t\t\t";
                    cin >> date;
                    reservation << date << '|';


                    cout << "\n\t\t Enter reservation time: ";
                    cin >> time;
                    reservation << time << '|';


                    cout << "\n\t\t Enter your phone number: ";
                    cin >> phone;
                    reservation << phone;


                    reservation.close();


                    cout << "\n\t\t Done" <<endl;

                    customermenu();


    }

void delete_reservation(){

                int topass;
                string name, numguest, date, time, phone;

                fstream reservation;
                reservation.open("reservation.txt");
                system("cls");


                vector <string> name_list;
                vector <string> numguest_list;
                vector <string> date_list;
                vector <string> time_list;
                vector <string> phone_list;




                while(!reservation.eof()){



                    getline(reservation,name,'|');
                    getline(reservation,numguest,'|');
                    getline(reservation,date,'|');
                    getline(reservation,time,'|');
                    getline(reservation,phone);



                    name_list.push_back(name);
                    numguest_list.push_back(numguest);
                    date_list.push_back(date);
                    time_list.push_back(time);
                    phone_list.push_back(phone);



                }

                reservation.close();


                //to check all element inside vectors
                for(int i=0; i<(name_list.size()-1); i++)
                {

                    cout<< name_list.at(i)<<"," <<numguest_list.at(i)<<","<<date_list.at(i)<<","<<time_list.at(i)<<","<<phone_list.at(i)<<endl;
                }




                vector<string> temp_name_list;
                vector<string> temp_numguest_list;
                vector<string> temp_date_list;
                vector<string> temp_time_list;
                vector<string> temp_phone_list;



                string todelete;


                system("cls");

                cout<<"\n\t************** CANCEL RESERVATION ******************\n\n";
                cout << setw(4) << "\n\t\t\t Enter your name : ";
                cin >> todelete;
                todelete=convert(todelete);
                bool found=false;

                for(int i=0;i<name_list.size();i++)

                    {
                        if(name_list.at(i)==todelete){
                            found=true;
                        }
                        else{

                            temp_name_list.push_back(name_list.at(i));
                            temp_numguest_list.push_back(numguest_list.at(i));
                            temp_date_list.push_back(date_list.at(i));
                            temp_time_list.push_back(time_list.at(i));
                            temp_phone_list.push_back(phone_list.at(i));
                        }
                    }



           if(found==false){

                                cout<<"unable to delete, no match found";
                            }

            if(found==true){

                //display item dah delete
                for(int i=0;i<temp_name_list.size();i++){
                    cout<< temp_name_list.at(i) <<'|'<<temp_numguest_list.at(i)<<'|'<<temp_date_list.at(i) <<'|'<<temp_time_list.at(i) <<'|'<<temp_phone_list.at(i) <<endl;

                }

                //delete old txt file

                if(remove("reservation.txt") !=0)
                    cout<<"\nError Deleting file\n";
                else{
                    cout<<"\nfile deleted\n";
                }

                //store all item back into txt file
                for(int i=0;i<temp_name_list.size();i++){
                    fstream addtemp;
                    addtemp.open("reservation.txt",ios::app);

                    addtemp<< endl << temp_name_list.at(i) <<'|'<<temp_numguest_list.at(i)<<'|'<<temp_date_list.at(i) <<'|'<<temp_time_list.at(i) <<'|'<<temp_phone_list.at(i);

                    addtemp.close();
                }

                }

    }

void sortname(){
                        int pass;
                        system("cls");
                        std::ifstream hse("reservation.txt");

                        std::vector<std::string> rows;
                        cout<<"\n\t***** CUSTOMER'S NAME ALPHABETICALLY *****\n\n";
                        cout<<endl;
                        // Read all the lines and add them to the rows vector


                        while(!hse.eof())
                            {
                                std::string line;
                                std::getline(hse, line);
                                rows.push_back(line);
                            }

                        // Sort the vector
                        std::sort(rows.begin(), rows.end());


                        // Print out all of the vectors values
                        std::vector<std::string>::iterator iterator = rows.begin();


                        for(; iterator != rows.end(); ++iterator)
                        std::cout << *iterator << std::endl;
                        getchar();

                    }


void displaymenu(){
    int choose, quantity;
    char decision, arr[100];
    string line;string Name;
            int Order_no, Quantity,i,j;
system("COLOR 3F");
system("cls");
    InitialCart();
     cout<<("\n\t\t\t*******************************************\n");
    cout<<("\t\t\t*******RESTAURANT RESERVATION SYSTEM*******\n");
    cout<<("\t\t\t*******************************************\n");
    cout<<("\n\t\t\t<<<<<<<<<<WELCOME USERS>>>>>>>>>>\n");

    do{


    cout<<("\n\n\t\t\t\t      MENU\n");
    cout<<("\t\t\t             ******");
    cout<<("\n\t\t\t[1] VIEW FOOD\n");
    cout<<("\n\t\t\t[2] VIEW DRINK\n");
    cout<<("\n\t\t\t[3] VIEW DESSERT\n");
    cout<<("\n\t\t\t[4] VIEW CART\n");
    cout<<("\n\t\t\t[5] SEARCH MENU \n");
    cout<<("\n\t\t\t[6] EXIT PROGRAM\n");
    cout<<("\n\t\t\t********************************");
    cout<<("\n\t\t\t********************************");
    cout<<("\n\t\t\tENTER YOUR CHOICE: ");
        cin>>choose;
        while (choose > 6 || choose <= 0)
        {
		std::cout << "\t\t\tInvalid number, try again: ";
		std::cin >> choose;
        }
        system("CLS");


        if (choose ==1)
        {
            Food();
        }

        if (choose ==2)
        {
           Drink();
        }

        if (choose ==3)
        {
            Dessert();

        }
        if (choose ==4)
        {
            do{
            int choose;
            Cart();

            cout<<endl<<"\t\t\tPress 1 delete item:"<<endl<<"\t\t\tPress 2 to update cart:"<<endl<< "\t\t\tPress any number to go back to Main Menu: ";
            cout<<endl<<"\t\t\tChoose your option: ";
            cin>>choose;

            if (choose == 1){
                    DeleteCart();
            }
            if (choose == 2){

                UpdateCart();
            }

            cout<<endl<<endl<<"\t\t\tPress Y to refresh: ";
            cout<<endl<< "\t\t\tPress any key to go back to Main Menu: ";
            std::cin >> decision;
            decision = toupper(decision);
            system("CLS");
            }
            while (decision=='Y');



        }
        if (choose ==5)
        {
            Search();
            system("cls");



        }
         if (choose==6){
            customermenu();
        }







    }
    while(decision !='Y');



}

void feedback(){
    string name,reserve, ui, needs, experience, food, recommend, clean, improve ;
    int option1, condition;

    ofstream feedback("feedback.txt" , ios::app);
    system("cls");


	cout<<("\n\t\t\t =================================================================\n");
    cout<<("\t\t\t ************* ONLINE RESTAURANT RESERVATION SYSTEM **************\n");
    cout<<("\t\t\t =================================================================\n");
    cout<<"Welcome to our feedback page!"<<endl;

    cout<<"\tPlease input your name : \t";
    cin>> name;
    feedback<<"name:\t";
	feedback<<name<<endl;

    cout<<"\tKindly enter your review based on the sections stated below. "<<endl;

    cout<<"\t1. Reservation System" <<endl;
    cout<<"\t\tEase of reservation making : \t";
    cin >> reserve ;
    feedback<<reserve<<endl;

    cout<<"\t\tUser interface friendliness : \t";
    cin>> ui;
    feedback<<ui<<endl;

    cout<<"\t\tDoes the system satisfy your needs (Yes/No) ? (If No, please state the reasons.) : \t";
    cin >> needs;
	feedback<<needs<<endl;

    cout<<endl<<"\t2. Restaurant "<<endl;
    cout<<"\t\tHow was your experience dining with us? : \t";
    cin>> experience;
    feedback<<experience<<endl;

    cout<<"\t\tHow was the food? : \t";
    cin>> food;
    feedback<<food<<endl;

    cout<< "\t\tDoes the cleanliness of the restaurant up to your standard? : \t";
    cin>> clean;
    feedback<<clean<<endl;

    cout<<"\t\tWould you recommend our restaurant to your friends/family? : \t";
    cin>> recommend;
    feedback<<recommend<<endl;

	cout<<"\t\tHow can we improve our services in future? : \t";
	cin>> improve;
	feedback<<improve<<endl;
	feedback<<"=========================================================\n";

	cout<<"====================================================================================================================\n";
	cout<<"\tYour feedbacks have been recorded for our future references." <<endl;
	cout<< "\tThank you for your support and loves :D " <<endl;
	cout<< "\tHave a nice day!"<<endl;

	cout << "Press 1 to return to main menu and 2 to return to customer menu." << endl;
	cin >> option1;

	while (condition != 1){
    if (option1 == 1){
        condition = condition + 1;
        mainmenu();
    }

    if (option1 == 2){
        condition = condition + 1;
        customermenu();
    }

	while (option1 < 0 || option1 > 2){
	cout << "Invalid choice, try again." << endl;
	cin >> option1;
	}
	}
}

void adminlogin(){
    string admin_id, admin_password;

    system("cls");
    p:
       cout<<("\n\t\t\t =================================================================\n");
    cout<<("\t\t\t ***************** ADMINISTRATOR LOGIN REQUIRED ******************\n");
    cout<<("\t\t\t =================================================================\n") << endl;
       cout<<"Please input your username and password to continue.\n"<<endl;
       cout<<"Username : ";
       cin>>admin_id;
       cout<<endl;
       cout<<"Password : ";
       cin>>admin_password;
       cout<<endl;

       if (admin_id=="admin") {
           if (admin_password=="12345") {

           //    option();
           cout<<"Welcome, Admin";
           adminmenu();
       }

           else {
                system("cls");
               cout<<"Wrong password, please try again"<<endl;
               goto p;
           }
       } else {
            system("cls");
			cout<<"Wrong username, please try again"<<endl;
            goto p;
       }
}

void mainmenu(){
    int userchoice;

        system("cls");
        maindisplay();
        cin >> userchoice;
        while(userchoice > 3 || userchoice <= 0){
            cout << "Invalid choice, try again.\n";
            cin >> userchoice;
        }

        if(userchoice == 1){
            adminlogin();
        }

        if(userchoice == 2){
            customermenu();
        }

        if(userchoice == 3){
            cout << "Thank you, have a nice day! :)" << endl;
            std::terminate(); //unable to use return for void therefore leaving it blank serves the same purpose
            //need to wait for the system to end
        }
}
int main(){

             string option;
             int cont;

             do
             {
                mainmenu();
                cout << "\n\t\t\t-----------------------------"<< endl;
                     cout << "\n\t\t\tDo you want to continue? : "<<endl;
                     cout << endl;
                     cout << "\n\t\t\tPRESS 1 TO CONTINUE" << endl;
                     cout << "\n\t\t\tPRESS ANY KEY TO EXIT"<< endl;
                     cin >> cont;
                     //unable to loop back delete and sort into admin menu therefore this is used

            }
             while (cont == 1 );

}

